/*******************************************************************************
File:			Main.h

				Main Video Overlay function library.

Version:		1.01

Copyright(c)	2004, Gary N. Dion (me@garydion.com). All rights reserved.
					This software is available only for non-commercial amateur radio
					or educational applications.  ALL other uses are prohibited.
					This software may be modified only if the resulting code be
					made available publicly and the original author(s) given credit.

*******************************************************************************/

/* extern function prototypes */

extern int	main(void);

